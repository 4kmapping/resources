  $.uofnapi = {
	appId: '28e8fb24cf721d9dd9a505dd8ae416a7',
	key: 'e63d4e5ec9fdd42e34b03d90c37f55e9',
	secret: '7e40f181f9a2ae7eb1a763c997b9a3a1'
	}


var CryptoJS=CryptoJS||function(g,l){var e={},d=e.lib={},m=function(){},k=d.Base={extend:function(a){m.prototype=this;var c=new m;a&&c.mixIn(a);c.hasOwnProperty("init")||(c.init=function(){c.$super.init.apply(this,arguments)});c.init.prototype=c;c.$super=this;return c},create:function(){var a=this.extend();a.init.apply(a,arguments);return a},init:function(){},mixIn:function(a){for(var c in a)a.hasOwnProperty(c)&&(this[c]=a[c]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.init.prototype.extend(this)}},
p=d.WordArray=k.extend({init:function(a,c){a=this.words=a||[];this.sigBytes=c!=l?c:4*a.length},toString:function(a){return(a||n).stringify(this)},concat:function(a){var c=this.words,q=a.words,f=this.sigBytes;a=a.sigBytes;this.clamp();if(f%4)for(var b=0;b<a;b++)c[f+b>>>2]|=(q[b>>>2]>>>24-8*(b%4)&255)<<24-8*((f+b)%4);else if(65535<q.length)for(b=0;b<a;b+=4)c[f+b>>>2]=q[b>>>2];else c.push.apply(c,q);this.sigBytes+=a;return this},clamp:function(){var a=this.words,c=this.sigBytes;a[c>>>2]&=4294967295<<
32-8*(c%4);a.length=g.ceil(c/4)},clone:function(){var a=k.clone.call(this);a.words=this.words.slice(0);return a},random:function(a){for(var c=[],b=0;b<a;b+=4)c.push(4294967296*g.random()|0);return new p.init(c,a)}}),b=e.enc={},n=b.Hex={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],f=0;f<a;f++){var d=c[f>>>2]>>>24-8*(f%4)&255;b.push((d>>>4).toString(16));b.push((d&15).toString(16))}return b.join("")},parse:function(a){for(var c=a.length,b=[],f=0;f<c;f+=2)b[f>>>3]|=parseInt(a.substr(f,
2),16)<<24-4*(f%8);return new p.init(b,c/2)}},j=b.Latin1={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],f=0;f<a;f++)b.push(String.fromCharCode(c[f>>>2]>>>24-8*(f%4)&255));return b.join("")},parse:function(a){for(var c=a.length,b=[],f=0;f<c;f++)b[f>>>2]|=(a.charCodeAt(f)&255)<<24-8*(f%4);return new p.init(b,c)}},h=b.Utf8={stringify:function(a){try{return decodeURIComponent(escape(j.stringify(a)))}catch(c){throw Error("Malformed UTF-8 data");}},parse:function(a){return j.parse(unescape(encodeURIComponent(a)))}},
r=d.BufferedBlockAlgorithm=k.extend({reset:function(){this._data=new p.init;this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=h.parse(a));this._data.concat(a);this._nDataBytes+=a.sigBytes},_process:function(a){var c=this._data,b=c.words,f=c.sigBytes,d=this.blockSize,e=f/(4*d),e=a?g.ceil(e):g.max((e|0)-this._minBufferSize,0);a=e*d;f=g.min(4*a,f);if(a){for(var k=0;k<a;k+=d)this._doProcessBlock(b,k);k=b.splice(0,a);c.sigBytes-=f}return new p.init(k,f)},clone:function(){var a=k.clone.call(this);
a._data=this._data.clone();return a},_minBufferSize:0});d.Hasher=r.extend({cfg:k.extend(),init:function(a){this.cfg=this.cfg.extend(a);this.reset()},reset:function(){r.reset.call(this);this._doReset()},update:function(a){this._append(a);this._process();return this},finalize:function(a){a&&this._append(a);return this._doFinalize()},blockSize:16,_createHelper:function(a){return function(b,d){return(new a.init(d)).finalize(b)}},_createHmacHelper:function(a){return function(b,d){return(new s.HMAC.init(a,
d)).finalize(b)}}});var s=e.algo={};return e}(Math);
(function(){var g=CryptoJS,l=g.lib,e=l.WordArray,d=l.Hasher,m=[],l=g.algo.SHA1=d.extend({_doReset:function(){this._hash=new e.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(d,e){for(var b=this._hash.words,n=b[0],j=b[1],h=b[2],g=b[3],l=b[4],a=0;80>a;a++){if(16>a)m[a]=d[e+a]|0;else{var c=m[a-3]^m[a-8]^m[a-14]^m[a-16];m[a]=c<<1|c>>>31}c=(n<<5|n>>>27)+l+m[a];c=20>a?c+((j&h|~j&g)+1518500249):40>a?c+((j^h^g)+1859775393):60>a?c+((j&h|j&g|h&g)-1894007588):c+((j^h^
g)-899497514);l=g;g=h;h=j<<30|j>>>2;j=n;n=c}b[0]=b[0]+n|0;b[1]=b[1]+j|0;b[2]=b[2]+h|0;b[3]=b[3]+g|0;b[4]=b[4]+l|0},_doFinalize:function(){var d=this._data,e=d.words,b=8*this._nDataBytes,g=8*d.sigBytes;e[g>>>5]|=128<<24-g%32;e[(g+64>>>9<<4)+14]=Math.floor(b/4294967296);e[(g+64>>>9<<4)+15]=b;d.sigBytes=4*e.length;this._process();return this._hash},clone:function(){var e=d.clone.call(this);e._hash=this._hash.clone();return e}});g.SHA1=d._createHelper(l);g.HmacSHA1=d._createHmacHelper(l)})();
(function(){var g=CryptoJS,l=g.enc.Utf8;g.algo.HMAC=g.lib.Base.extend({init:function(e,d){e=this._hasher=new e.init;"string"==typeof d&&(d=l.parse(d));var g=e.blockSize,k=4*g;d.sigBytes>k&&(d=e.finalize(d));d.clamp();for(var p=this._oKey=d.clone(),b=this._iKey=d.clone(),n=p.words,j=b.words,h=0;h<g;h++)n[h]^=1549556828,j[h]^=909522486;p.sigBytes=b.sigBytes=k;this.reset()},reset:function(){var e=this._hasher;e.reset();e.update(this._iKey)},update:function(e){this._hasher.update(e);return this},finalize:function(e){var d=
this._hasher;e=d.finalize(e);d.reset();return d.finalize(this._oKey.clone().concat(e))}})})();


var UofnApi = function() {
	return {
		defaults: {
			version: '1.0',
			oauthvars: {},
			apiserver: 'http://systems.uofn.edu/api/php/'
		},
		init: function() {

			this.defaults.oauthvars.appId_ = $.uofnapi.appId;
			this.defaults.oauthvars.apiKey = $.uofnapi.key;
			this.defaults.oauthvars.secret_key = $.uofnapi.secret;

		},

		generate_nonce_timestamp: function(params, success, error) {
			return $.ajax({
				url: this.defaults.apiserver + '?method=apikey/generate_nonce_timestamp',
				data: params,
				async: false
			});
		},
		serializeObj: function(obj) {
			var str = [];
			for (var p in obj) {
				if (typeof obj[p] == 'object') {
					//console.log('recalculate objp');
					obj[p] = objToArray(obj[p])[0];
					obj[p] = obj[p].toString();
				}
				//console.log('obj,p',p,obj[p],typeof obj[p]);
				str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
			}
			return str.join("&");
		},
		unparam: function(query) {
			var setValue = function(root, path, value) {
				if (path.length > 1) {
					var dir = path.shift();
					if (typeof root[dir] == 'undefined') {
						root[dir] = path[0] == '' ? [] : {};
					}

					arguments.callee(root[dir], path, value);
				} else {
					if (root instanceof Array) {
						root.push(value);
					} else {
						root[path] = value;
					}
				}
			};
			var nvp = query.split('&');
			var data = {};
			for (var i = 0; i < nvp.length; i++) {
				var pair = nvp[i].split('=');
				var name = decodeURIComponent(pair[0]);
				var value = decodeURIComponent(pair[1]);

				var path = name.match(/(^[^\[]+)(\[.*\]$)?/);
				var first = path[1];
				if (path[2]) {
					//case of 'array[level1]' || 'array[level1][level2]'
					path = path[2].match(/(?=\[(.*)\]$)/)[1].split('][')
				} else {
					//case of 'name'
					path = [];
				}
				path.unshift(first);

				setValue(data, path, value);
			}
			return data;
		},
		execute: function($controller, $method, $paramsvar, callback) {
			var $method_ = $controller + '/' + $method,
				$ch = encodeURIComponent('/');
			$method_ = $method_.replace('/', $ch);
			$params = 'method=' + $method_ + '&';

			var requesturi = this.defaults.apiserver + '?' + $params;
			var data = {},
				_this = this;
			var parsedurlparams = {};
			delete _this.defaults.oauthvars.token;

			//check if it's external
			if (requesturi.indexOf('http') >= 0 && requesturi.indexOf('generate_nonce_timestamp') < 0 && requesturi.indexOf('.json') < 0) {
				var pos = requesturi.indexOf('?');
				if (pos > -0) {
					parsedurlparams = requesturi.substring(pos + 1);
					var noncegen = this.generate_nonce_timestamp(_this.defaults.oauthvars);
					noncegen.done(function(nonce) {
						// parsedurlparams =  jQuery.deparam(parsedurlparams.toString());
						parsedurlparams = $paramsvar;

						// get timestamp

						parsedurlparams = $.extend({
							method: $controller + '/' + $method
						}, parsedurlparams);
						_this.defaults.oauthvars.nonce = nonce.timestamp;
						parsedurlparams = $.extend(parsedurlparams, data)
						parsedurlparams = $.extend(parsedurlparams, _this.defaults.oauthvars)

						parsedurlparams = _this.serializeObj(parsedurlparams);
						parsedurlparams = parsedurlparams.toString() + '';
						var hmac = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA1, _this.defaults.oauthvars.secret_key);
						hmac.update(parsedurlparams);
						_this.defaults.oauthvars.token = hmac.finalize().toString();
						//data = JSON.parse('{"' + decodeURI(parsedurlparams.replace(/&/g, "\",\"").replace(/=/g, "\":\"")) + '"}')
						data = _this.unparam(parsedurlparams);
						data.method = $controller + '/' + $method;
						data = $.param($.extend(data, _this.defaults.oauthvars));
					});

				}
			} else data = $.param($.extend(data, _this.defaults.oauthvars));
			var result = $.ajax({
				url: this.defaults.apiserver + '?method=' + $controller + '/' + $method,
				data: data,
				success: callback,
				type: 'POST'
			});
		}
	}
}();