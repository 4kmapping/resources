// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};

$.ajaxSetup({
  cache: false
});

$(document).ready(function() {
  UofnApi.init();


});
$(document).on('ajaxStart', function(e) {
  // spinner = new Spinner(opts).spin(document.body);
  $.mobile.loading('show');
});
$(document).on('ajaxComplete', function(e) {
  $.mobile.loading('hide');
  // spinner.stop();
});

function loadZoneByPos(latitude, longitude) {


  UofnApi.execute('4k', 'findOzByLocation', {
    lat: latitude,
    lon: longitude
  }, function(data) {
    amplify.store('city', 'Current Location');
    amplify.store('country', 'GPS');

    console.log('data', data);
    amplify.store('zonedata', data.features[0].attributes);
    $.mobile.changePage('#stats', {
      transition: 'slide'
    });
  });
}

function loadZone(city, country) {
  amplify.store('city', city);
  amplify.store('country', country);

  var address = city + ' ' + country;
  console.log('load address', address);

  UofnApi.execute('4k', 'findOzByAddress', {
    address: address
  }, function(data) {
    console.log('data', data);
    amplify.store('zonedata', data.features[0].attributes);
    $.mobile.changePage('#stats', {
      transition: 'slide'
    });
  });

}

$(document).on('pagebeforeshow', '#home', function() {


  $('body.ui-mobile-viewport').animate({
    'background-position-x': '10%',
    'background-position-y': '0%'
  }, 1000, 'easeOutExpo');

});

function addCommas(n) {
  var rx = /(\d+)(\d{3})/;
  return String(n).replace(/^\d+/, function(w) {
    while (rx.test(w)) {
      w = w.replace(rx, '$1,$2');
    }
    return w;
  });
}

function getCurrentLocation() {
  var obj = {};
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      obj.latitude = position.coords.latitude;
      obj.longitude = position.coords.longitude;
      loadZone(obj.latitude, obj.longitude);
      return true;
    });

  } else return false
}

$(document).on('pagebeforeshow', '#stats', function() {

  var zone = amplify.store('zonedata'),
    city = amplify.store('city');
  console.log('zone', zone);
  $('#zoneName').html(zone.Zone_Name);
  $('.cityName').html(city);
  $('#worldid').html(zone.WorldID);
  $('#Access_Wat').html((zone.Access_Wat * 100).toFixed(2) + '%');
  $('#AdultPerce').html((zone.AdultPerce * 100).toFixed(2) + '%');
  $('#Adult_Lite').html((zone.Adult_Lite * 100).toFixed(2) + '%');
  $('#BLNIxPop2').html(zone.BLNIxPop2);
  $('#Christian_').html(zone.Christian_ + " per 1 million");
  $('#Evangelize').html((zone.Evangelize * 100).toFixed(2) + '%');
  $('#GCC').html((zone.GCC * 100).toFixed(2) + '%');
  $('#HDI').html(zone.HDI);
  $('#HSI').html(zone.HSI);
  $('#Life_Expec').html(zone.Life_Expec);
  $('#Offers').html(zone.Offers);
  $('#Population').html(addCommas(zone.Population));
  $('#Response').html(zone.Response);
  $('#SLNIxPop2').html(zone.SLNIxPop2);
  $('#THNIxPop4').html(zone.THNIxPop4);
  $('#Under_5_Mo').html(zone.Under_5_Mo + ' per 1000');
  $('#World').html(zone.World);



  $('body.ui-mobile-viewport').animate({
    'background-position-x': '80%',
    'background-position-y': '0%'
  }, 1000, 'easeOutExpo');

});



$(document).on('pagebeforeshow', '#whatzone', function() {
  $('body.ui-mobile-viewport').animate({
    'background-position-x': '50%',
    'background-position-y': '0%'
  }, 1000, 'easeOutExpo');



});

$(document).on('pageinit', '#whatzone', function() {
  $('.findzone').on('tap', function(ev) {
    var city = $('#city').val();
    var country = $('#country').val();
   
    loadZone(city, country);
  });

  $('#currentLocation').on('tap', function(ev) {
    getCurrentLocation();

  });
});

function fixSizeUnderlay(page) {
  $('.ui-underlay-over', '#' + page).height(screen.height);
  $('.ui-underlay', '#' + page).height(screen.height);
  $('.ui-content', '#' + page).css('min-height', screen.height);

}


function fixUnderlay(page) {
  if (page == 'home') getRandomFundo(true);
  else {
    $('.ui-underlay-over', '#' + page).height(screen.height);

    $('.ui-underlay', '#' + page).height(screen.height);

    $('.ui-content', '#' + page).css('min-height', screen.height);
    $('.ui-underlay', '#' + page).css('background', 'url(' + getRandomFundo(false) + ')');
    $('.ui-underlay', '#' + page).css('background-size', 'cover');
  }
}

function loadUnidadesInternas(id) {
  var unidades = amplify.store('unidades'),
    html = '<option value="-1" selected> Outras Unidades</option>',
    select = '';
  for (var i = 0; i < unidades.length; i++) {
    if (id != unidades[i].id)
      html += '<option value="' + unidades[i].id + '" ' + select + '>' + unidades[i].name + '</option>';
  }
  return html;

}

function getRandomFundo(home) {
  var unidade = amplify.store('unidade'),
    url = $.apiurl + '/get_fundos_home',
    _this = this;
  fundos = [];
  if (home) {
    url = $.apiurl + '/get_fundos_home',

    // console.log('home');
    $.ajax({
      async: false,
      crossdomain: true,
      dataType: 'jsonp',
      url: url
    }).done(function(data) {
      //console.log('data', data);
      fundos = data.fundos;

      //console.log('fundos', fundos);

      var index = Math.floor(Math.random() * fundos.length * 11);
      index = Math.floor(index / 11);
      retorno = fundos[index];
      if (retorno)
        if (retorno.length > 1) {
          var page = 'home';
          $('.ui-underlay-over', '#' + page).height(screen.height);

          $('.ui-underlay', '#' + page).height(screen.height);

          $('.ui-content', '#' + page).css('min-height', screen.height);
          $('.ui-underlay', '#' + page).css('background', 'url(' + retorno[0] + ')');
          $('.ui-underlay', '#' + page).css('background-size', 'cover');
          return retorno[0];
        }
    });
  } else {
    // console.log('nidade', unidade);
    if (unidade)
      fundos = unidade.fundos;
    else fundos = [];

    console.log('fundos', fundos);
    var index = Math.floor(Math.random() * fundos.length * 11);
    index = Math.floor(index / 11);
    retorno = fundos[index];
    if (retorno)
      if (retorno.length > 1)
        return retorno[0];
  }

}

function getFundos() {
  var unidade = amplify.store('unidade'),
    fundos = unidade.fundos;
  return fundos;
}
//SINGLE

$(document).on('pagebeforeshow', '#single', function() {

  var id = amplify.store('single'),
    html = loadUnidadesInternas(id);

  $('.ui-select', '#single').hide();
  $('#escolhaunidade_interna', '#single').html(html);
  $('.ui-select', '#single').fadeIn();
  //carregar unidade (single)
  var url = $.apiurl + '/get_unidade';
  $.ajax({
    url: url,
    dataType: 'jsonp',
    crossdomain: true,
    data: {
      id: id
    }
  }).done(function(data) {
    amplify.store('unidade', data);
    $('#titulounidade', '#single').html(data.name);
    fixUnderlay('single');
    $('#phone', '#single').attr('href', 'tel:' + data.telefone); //W3C - tel:+1800229933
    var geo = '';
    if (navigator.userAgent.match(/Android/i)) {
      geo = 'geo:' + data.gps;
      //code for Android here
    } else {
      //code for iOs
      //http://developer.apple.com/library/ios/#featuredarticles/iPhoneURLScheme_Reference/Articles/MapLinks.html
      geo = 'http://maps.apple.com/?sll=' + data.gps;
    }
    $('#geolocation', '#single').attr('href', geo);
    // console.log('single loaded', data);

  });

  $('#escolhaunidade_interna').on('change', function(el) {
    if ($(this).val() != -1) {
      carregaSingle($(this).val());
    }
  });

});

$(document).on('pagebeforeshow', '#conteudo', function() {
  fixUnderlay('conteudo');
  var unidade = amplify.store('unidade'),
    id = amplify.store('single'),
    html = loadUnidadesInternas(id);

  $('.ui-select', '#conteudo').hide();
  $('#escolhaunidade_interna', '#conteudo').html(html);
  $('.ui-select', '#conteudo').fadeIn();

  $('#nomeunidade', '#conteudo').html(unidade.name);
  $('#texto', '#conteudo').html(unidade.casa);


  $('#escolhaunidade_interna').on('change', function(el) {
    if ($(this).val() != -1) {
      carregaSingle($(this).val());
    }
  });

});


$(document).on('pagebeforeshow', '#cardapio', function() {
  fixUnderlay('cardapio');
  var unidade = amplify.store('unidade'),
    id = amplify.store('single'),
    html = loadUnidadesInternas(id);

  $('.ui-select', '#cardapio').hide();
  $('#escolhaunidade_interna', '#cardapio').html(html);
  $('.ui-select', '#cardapio').fadeIn();

  $('#nomeunidade', '#cardapio').html(unidade.name);

  var url = $.apiurl + '/get_cardapio';
  $.ajax({
    url: url,
    dataType: 'jsonp',
    crossdomain: true,
    data: {
      id: id
    }
  }).done(function(data) {
    var html = '';
    for (var i = 0; i < data.cardapio.length; i++) {
      html += '<li> <a href=\'javascript:carregaCategoria("' + data.cardapio[i].id + '","' + data.cardapio[i].name + '","' + data.cardapio[i].slug + '");\' class="subcardapio" style="font-size: 1.3em;margin-top:-7px;" data-name="' + data.cardapio[i].name + '" data-slug="' + data.cardapio[i].slug + '" data-id="' + data.cardapio[i].id + '">' + data.cardapio[i].name + '</a></li>';

    }
    $('#listacardapio').html(html);
    $('#listacardapio').listview('refresh');
  });


  $('#escolhaunidade_interna').on('change', function(el) {
    if ($(this).val() != -1) {
      carregaSingle($(this).val());
    }
  });


});


function carregarItem(id) {
  amplify.store('item', id);
  $.mobile.changePage('#item-cardapio', {
    transition: 'slidefade'
  });
}

function carregaCategoria(id, name, slug) {

  var categoria = {
    id: id,
    name: name,
    slug: slug
  };
  amplify.store('categoria', categoria);
  $.mobile.changePage('#categoria', {
    transition: 'slidefade'
  });
}

$(document).on('pagebeforeshow', '#categoria', function() {
  fixSizeUnderlay('categoria');
  $('#listacategoria').html('<li><i class="icon-spinner icon-spin"></i> Carregando Categoria </li>');
  $('#listacategoria').listview('refresh');

  var unidade = amplify.store('unidade'),
    id = amplify.store('single'),
    categoria = amplify.store('categoria'),
    html = loadUnidadesInternas(id);

  $('.ui-select', '#categoria').hide();
  $('#escolhaunidade_interna', '#categoria').html(html);
  $('.ui-select', '#categoria').fadeIn();

  $('#nomeunidade', '#categoria').html(unidade.name);
  $('#categorianame', '#categoria').html(categoria.name);

  var url = $.apiurl + '/get_lista_itens';
  $.ajax({
    url: url,
    dataType: 'jsonp',
    crossdomain: true,
    data: {
      id: categoria.id
    }
  }).done(function(data) {
    var html = '';
    for (var i = 0; i < data.itens.length; i++) {
      if (data.itens[i].thumb) {
        img = ' <img src="' + data.itens[i].thumb + '">';
      } else img = ' <img src="assets/img/default.jpg">';
      html += '<li><a href=\'javascript:carregarItem("' + data.itens[i].id + '")\' class="item" data-id="' + data.itens[i].id + '">' + img + data.itens[i].name + '</a></li>'; //<p> '+data.itens[i].description +'</p>

    }
    $('#listacategoria').html(html);
    $('#listacategoria').listview('refresh');
  });


  $('#escolhaunidade_interna').on('change', function(el) {
    if ($(this).val() != -1) {
      carregaSingle($(this).val());
    }
  });

  $('.item-cardapio').on('tap', function(el) {

    var id = $(this).data('id');
    amplify.store('item', id);
    $.mobile.changePage('#item-cardapio', {
      transition: 'slidefade'
    });
  });

});


$(document).on('pagebeforeshow', '#eventos', function() {
  fixUnderlay('eventos');
  var unidade = amplify.store('unidade'),
    id = amplify.store('single'),
    html = loadUnidadesInternas(id);

  $('.ui-select', '#eventos').hide();
  $('#escolhaunidade_interna', '#eventos').html(html);
  $('.ui-select', '#eventos').fadeIn();

  $('#nomeunidade', '#eventos').html(unidade.name);
  $('#texto', '#eventos').html(unidade.eventos);


  $('#escolhaunidade_interna').on('change', function(el) {
    if ($(this).val() != -1) {
      carregaSingle($(this).val());
    }
  });

});


$(document).on('pagebeforeshow', '#item-cardapio', function() {
  fixSizeUnderlay('item-cardapio');
  var id = amplify.store('item'),
    categoria = amplify.store('categoria');

  $('#nomecategoria', '#item-cardapio').html(categoria.name);

  //carregar unidade (single)
  var url = $.apiurl + '/get_item';
  $.ajax({
    url: url,
    async: false,
    dataType: 'jsonp',
    crossdomain: true,
    data: {
      id: id
    }
  }).done(function(data) {
    var img = 'assets/img/item.jpg';
    if (data.thumbnail) img = data.thumbnail;
    $('.thumb_item', '#item-cardapio').html('<img src="' + img + '"/>');
    $('#descricao', '#item-cardapio').html(data.description);
    $('#itemname', '#item-cardapio').html(data.name);

    // console.log('item loaded', data);
  });


});